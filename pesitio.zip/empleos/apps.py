from django.apps import AppConfig


class EmpleosConfig(AppConfig):
    name = 'empleos'
